(function(){const i="PROOFLY_RPC_BRIDGE";window.addEventListener("message",t=>{if(t.source!==window)return;const r=t.data;!r||r.namespace!==i||r.channel!=="request"||chrome.runtime.sendMessage({type:"PROOFLY_RPC_REQUEST",payload:r},e=>{const a={namespace:i,channel:"response",id:r.id};chrome.runtime.lastError?a.error={code:4900,message:chrome.runtime.lastError.message??"Runtime relay failure."}:e!=null&&e.ok?a.result=e.result:a.error=(e==null?void 0:e.error)??{code:4900,message:"Unknown runtime relay error."},window.postMessage(a,"*")})});
//# sourceMappingURL=relay.ts-B1um-d-y.js.map
})()
